# Testing



mtd(pollutant = 'PM2.5', dates = pm25$datetime, ref_data = pm25$reference_pm25, sensor_data = pm25$sensor_pm25, reference_uncertainty = 0.5, sensor_uncertainty = 5)
