
#' Plots a Modified Target Diagram (MTD)
#'
#' @param pollutant String giving pollutant (one of "CO","CO2","CO2","NO","NO2","O3","PM1","PM10","PM2.5")
#' @param dates Vector of datetimes of the measurements
#' @param ref_data Numeric vector of observations from reference
#' @param sensor_data Numeric vector of observations from sensor
#' @param reference_uncertainty Random standard uncertainty of the results of the reference method, given as a constant value for all reference values
#' @param sensor_uncertainty Between standard uncertainty of the sensor, given as a constant value for all yis sensor values
#'
#' @return A plot
#' @export
#'
#' @examples
#' data(pm25)
#' mtd(pollutant = 'PM2.5',
#'     dates = pm25$datetime,
#'     ref_data = pm25$reference_pm25,
#'     sensor_data = pm25$sensor_pm25,
#'     reference_uncertainty = 0.5,
#'     sensor_uncertainty = 5)

mtd <- function(pollutant, dates, ref_data, sensor_data, reference_uncertainty, sensor_uncertainty)
{
    pollutant = match.arg(pollutant,
                          choices = c("CO","CO2","CO2","NO","NO2","O3","PM1","PM10","PM2.5"    ,"RH","RH_int","Temp","Temp_int","Press"))


    stopifnot(length(ref_data) == length(sensor_data))
    n_obs = length(ref_data)

    # Create a data.frame for U_orth_DF
    df = data.frame(case = 1:n_obs,
                    date = dates,
                    xis = ref_data,
                    yis = sensor_data,
                    ubs_rm = reference_uncertainty,
                    ubs_s = sensor_uncertainty)

    # Run orthogonal regression
    U.orth.List = U_orth_DF(df, Regression = 'OLS', Add.ubss = FALSE)

    # Get the DQO thresholds
    DQO = get.DQO(name.gas = pollutant, unit.ref = 'ug/m3')

    # Run the target diagram function
    Target.Diagram(Sensor_name = '',
                   Mat = U.orth.List[["Mat"]],
                   ubsRM = reference_uncertainty,
                   ubss = sensor_uncertainty,
                   b0 = U.orth.List$b0,
                   b1 = U.orth.List$b1,
                   Unit.Ref = 'ug/m3',
                   Unit.sensor = 'ug/m3',
                   xAxisLabel = NULL,
                   yAxisLabel = NULL,
                   DQO.1 = DQO$DQO.1/DQO$LV,
                   DQO.2 = DQO$DQO.2/DQO$LV,
                   DQO.3 = DQO$DQO.3/DQO$LV,
                   LAT = DQO$LAT,
                   UAT = DQO$UAT,
                   LV = DQO$LV,
                   AT = DQO$AT,
                   sdm_sdo = U.orth.List[["sdm"]] > U.orth.List[["sdo"]],
                   BeginEnd = as.character(dates),
                   with.ubss = FALSE)



}
